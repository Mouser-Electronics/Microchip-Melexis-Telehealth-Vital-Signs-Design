/*
 * File:   crc16.h
 * Author: Brandon Mitchell
 *
 * Created on May 6, 2015, 1:34 PM
 *
 * 16 Bit CRC
 */

#ifndef CRC16_H
#define	CRC16_H

#ifdef	__cplusplus
extern "C" {
#endif

//#include <stdint.h>
//#include <stdlib.h>

#define INITIAL_CRC16_VALUE 0xFFFF


typedef unsigned int CRC16;

CRC16 CalcCrc16( CRC16 crc, const unsigned char * pStr, const unsigned int lenStr );

#endif
