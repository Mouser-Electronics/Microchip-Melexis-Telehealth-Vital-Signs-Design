/*
 * File:   btle_uart.h
 * Author: Brandon Mitchell
 *
 * Created on February 9, 2015, 2:57 PM
 *
 * Comm interface between microcontroller and RN4020
 */

#ifndef BTLE_UART_H
#define	BTLE_UART_H

#ifdef	__cplusplus
extern "C" {
#endif

////////////////////////////////////////////////////////////////////////////////
// DEFINES

// Uncomment this for more verbose feedback
//#define _DEBUG

// Uncomment this for initial RN4020 configuration (factory default baud rate)
//#define _INIT_RN4020_CONFIG

////////////////////////////////////////////////////////////////////////////////
// CONSTANTS

// Define these pins for your particular MCU hardware configuration
#define BTLE_CONNECTED              LATBbits.LATB10 //PIO1
#define WAKE_SW                     LATBbits.LATB10
#define WAKE_HW                     LATBbits.LATB10
#define MLDP_EN                     LATBbits.LATB10
//#define BTLE_UART_TX_IS_BUSY        (!TXIF)
//#define BTLE_UART_BYTE_RECEIVED     RCIF

#define BTLE_UART_RX_BUFFER_SIZE    270
#define BTLE_UART_RX_LINE_SIZE      79

#define BTLE_STATUS_ALL_FLAGS           0xFF
#define BTLE_STATUS_TX_FLAG             0x80
#define BTLE_STATUS_RX_FLAG             0x40
#define BTLE_STATUS_RX_BUFFER_FULL_FLAG 0x20
#define BTLE_STATUS_OERR_ERROR_FLAG     0x10
#define BTLE_STATUS_FERR_ERROR_FLAG     0x08
#define BTLE_STATUS_TX_ERROR_FLAG       0x04
#define BTLE_STATUS_RX_ERROR_FLAG       0x02

////////////////////////////////////////////////////////////////////////////////
// TYPES

typedef struct btleUart_define {
    unsigned char rxFifo[BTLE_UART_RX_BUFFER_SIZE];
    unsigned char junkByte;
    unsigned int  rxFifoInIndex, rxFifoOutIndex;
    unsigned int  rxBufferSize;
    unsigned char btleUartFlags;
    unsigned char rxResponse[BTLE_UART_RX_LINE_SIZE + 1];
    unsigned int  numLinesReady;
} btleUart_t;

typedef struct btleCommand_define {
    const unsigned char * commandString;
    const unsigned char * responseString;
    unsigned int responseLength;
    unsigned int delayTime_ms;
} btleCommand_t;

typedef enum exitCondition_define {
    EXIT__SUCCESS, EXIT__FAILURE
} exitCondition_t;

////////////////////////////////////////////////////////////////////////////////
// ENUMS

// btleCommandTable index enum
enum {
    //Set Commands
    SET_SERIALIZED_NAME, SET_BAUD_RATE, SET_FACTORY_DEFAULT, START_TIMER1_us,
    START_TIMER2_us, START_TIMER3_us, SET_CENTRAL_NAME, SET_PERIPHERAL_NAME,
    SET_CENTRAL_RESOURCE, SET_PERIPHERAL_RESOURCE, SET_CENTRAL_SERVICE, SET_PERIPHERAL_SERVICE,
    SET_TIMING,
    //Get Commands
    GET_SERIALIZED_NAME, GET_BAUD_RATE, GET_MODULE_FIRMWARE_VERSION, GET_HARDWARE_VERSION,
    GET_MODEL_NAME, GET_MANUFACTURER_NAME, GET_SOFTWARE_VERSION, GET_SERIAL_NUMBER,
    GET_NAME, GET_RESOURCE, GET_SERVICE, GET_TIMING,
    //Action Commands
    ECHO_ON, ECHO_OFF, ECHO_TEST, ADVERTISE, BOND, DISPLAY_INFO, CONNECT, START_SCAN, GET_HELP,
    ENTER_OBSERVE_MODE, EXIT_OBSERVE_MODE, DISCONNECT, GET_SIGNAL_STRENGTH,
    ENTER_BROADCAST_MODE, ENTER_DORMANT_MODE, REBOOT, CHANGE_TIMING, UNBOND,
    GET_FIRMWARE_VERSION, STOP_SCAN, STOP_ADVERTISE, STOP_CONNECTION,
    //Services
    LIST_CLIENT_SERVICES, LIST_SERVER_SERVICES,
    //PrivateServices
    SET_PRIVATE_CHARACTERISTIC, SET_PRIVATE_SERVICE, CLEAR_PRIVATE_SERVICE,
    //MLDP
    ENTER_MLDP_MODE, SET_MLDP_SECURITY_NONE, SET_MLDP_SECURITY_ENCRYPT
};

////////////////////////////////////////////////////////////////////////////////
// PUBLIC DATA

extern btleUart_t btleUart;
extern const btleCommand_t btleCommandTable[];

////////////////////////////////////////////////////////////////////////////////
// Interface Function Declarations

void            InitBtleUart( void );
exitCondition_t BtleFullFactoryReset( void );
exitCondition_t ConfigureBtleCentral( void );
exitCondition_t ConfigureBtlePeripheral( void );
exitCondition_t ReadAllRxFifo( char * rxFifoString );
exitCondition_t ReadLineRxFifo( char * rxFifoString );
void            ClearRxFifo( void );
exitCondition_t HandleBtleCommand( const unsigned char command );
exitCondition_t HandleRawBtleCommand( const btleCommand_t * command );
exitCondition_t SendRawBtleCommand( const btleCommand_t * command );
void            BtleMaskToString( const unsigned long bitMask, unsigned char * solution);
void            BtleStringToAsciiEncode(const unsigned char * inString, unsigned char * outString, const unsigned char maxOutStringLength );
void            BtleAsciiHexToString( const unsigned char * hex, unsigned char * outString );

#ifdef	__cplusplus
}
#endif

#endif	/* BTLE_UART_H */

