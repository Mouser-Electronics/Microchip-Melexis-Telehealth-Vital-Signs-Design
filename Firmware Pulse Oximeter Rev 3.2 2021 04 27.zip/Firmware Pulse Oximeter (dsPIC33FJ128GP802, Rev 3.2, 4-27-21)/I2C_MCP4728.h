/************************************************************************************************************
 SOFTWARE COPYRIGHT NOTICE:

 � [2013] Microchip Technology Inc. and its subsidiaries.
 You may use this software and any derivatives exclusively with Microchip products. 

 THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS,
 COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 

 IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT
 EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

 MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.

************************************************************************************************************/

//********************************************************************
// File Name:       I2C_MCP4728.h
//********************************************************************

#ifndef _I2C_MCP4728_H_
#define _I2C_MCP4728_H_

//This file contains the function prototypes for the i2c function
#define PAGESIZE	32

//Low Level Functions
void IdleI2C(void);
void StartI2C(void);
unsigned char WriteI2C(unsigned char);
void StopI2C(void);
void RestartI2C(void);
unsigned int getsI2C(unsigned char*, unsigned char);
void NotAckI2C(void);
void Init_I2C(void);
unsigned char ACKStatus(void);
unsigned int getI2C(void);
void AckI2C(void);
unsigned int EEAckPolling(unsigned char);
unsigned int putstringI2C(unsigned char*);

//High Level Functions for Low Density Devices
unsigned int LDByteReadI2C(unsigned char, unsigned char, unsigned char*, unsigned char);
unsigned int LDByteWriteI2C(unsigned char, unsigned char, unsigned char);
unsigned int LDPageWriteI2C(unsigned char, unsigned char, unsigned char*);
unsigned int LDSequentialReadI2C(unsigned char, unsigned char, unsigned char*, unsigned char);

//High Level Functions for High Density Devices
unsigned int HDByteReadI2C(unsigned char, unsigned char, unsigned char, unsigned char*, unsigned char);
unsigned int HDByteWriteI2C(unsigned char, unsigned char, unsigned char, unsigned char);
unsigned int HDPageWriteI2C(unsigned char, unsigned char, unsigned char, unsigned char*);
unsigned int HDSequentialReadI2C(unsigned char, unsigned char, unsigned char, unsigned char*, unsigned char);

//MCP4726 (1)Fast Write and (2)Write to DAC Input Register and EEPROM

unsigned int MCP47x6FastModeWriteI2C(unsigned char, unsigned char, unsigned char);
unsigned int MCP47x6EEPROMWriteI2C(unsigned char, unsigned char, unsigned char, unsigned char);

void I2C_MCP4728_Write (unsigned char _1stByte, unsigned char _2ndByte, unsigned char _3rdByte, unsigned char _4thByte);


#endif
