/* 
 * File:   peripheral_comm.h
 * Author: Brandon Mitchell
 *
 * Created on April 27, 2015, 1:34 PM
 *
 * Peripheral to Hub Communication
 */

#ifndef HUB_COMM_H
#define	HUB_COMM_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "btle.h"

////////////////////////////////////////////////////////////////////////////////
// CONSTANTS

#define MAX_NUM_MAC_ADDRESS 8
#define MAC_ADDRESS_LENGTH  12

////////////////////////////////////////////////////////////////////////////////
// TYPES

typedef enum periphType_define {
    NONE, HUB
} periphType_t;
    
typedef struct periph_define {
    unsigned char macAddress[MAC_ADDRESS_LENGTH + 1];
    periphType_t    type;
} periph_t;

typedef struct pList_define {
    periph_t      periph[MAX_NUM_MAC_ADDRESS];
    int           highestIndex;
    unsigned char valid;
} pList_t;

////////////////////////////////////////////////////////////////////////////////
// PUBLIC DATA

extern pList_t pList;

////////////////////////////////////////////////////////////////////////////////
// Interface Function Declarations

void            InitPeripheral( void );
exitCondition_t FindHub( void );
exitCondition_t ConnectToHub( int index );
void            SendData( periphType_t type, unsigned int data1, unsigned int data2 );
exitCondition_t DeleteHubFromList( int index );


#ifdef	__cplusplus
}
#endif

#endif	/* HUB_COMM_H */

