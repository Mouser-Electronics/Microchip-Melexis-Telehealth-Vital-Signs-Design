//**********************************************************************************************************************
// MLX90632 I2C Read & Write code
// Function names must match pre-defined in the mlx90632_depends.h file.
// Z.F. 11/11/2020
//**********************************************************************************************************************

#include "p33Fxxxx.h"
#include "I2C_MCP4728.h"
#include "mlx90632.h"

/* Definition of I2C address of MLX90632 */
#define CHIP_ADDRESS 0x3a << 1
/* HAL_I2C_Mem_Read()/Write() are used instead of Master_Transmit()/Receive() because repeated start condition is needed */
/* Implementation of I2C read for 16-bit values */
int32_t mlx90632_i2c_read(uint16_t register_address, uint16_t *value)
{
	uint8_t data[2];
//	int32_t ret;
//	ret = HAL_I2C_Mem_Read(&hi2c1, CHIP_ADDRESS, register_address, 2, data, sizeof(data), 100);
//    //Endianness
//	*value = data[1]|(data[0]<<8);
//	return ret;
    
    //Chip Address Byte for MLX90632 is a 7-bit slave address 0x3A (if ADDR-pin=0), or 0x3B (if ADDR-pin=1).
	//The first/start/write 8-bit control byte is chip address(0x3a<<1) + /W(=0): 0 1 1 1 0 1 0 0
    //The second/read 8-bit control byte is chip address(0x3a<<1) + R(=1): 0 1 1 1 0 1 0 1
    uint8_t ControlByte, HighAdd, LowAdd, length;
    ControlByte = CHIP_ADDRESS;     //e.g. 011 1010 0 (for 3A)
    length = 2;     // read 2 bytes data
    
    HighAdd = (register_address >> 8) & 0x00FF;
    LowAdd = register_address & 0x00FF;

	IdleI2C();						//Wait for bus Idle
	StartI2C();						//Generate Start condition
	WriteI2C(ControlByte);			//send control byte for write
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(HighAdd);				//Send High Address
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(LowAdd);				//Send Low Address
    IdleI2C();						//Wait for bus Idle

	RestartI2C();					//Generate Restart
	WriteI2C(ControlByte | 0x01);	//send control byte for Read
    IdleI2C();						//Wait for bus Idle

	getsI2C(data, length);			//Read Length number of bytes to Data
	NotAckI2C();					//send Not Ack
	StopI2C();						//Send Stop Condition
	
    *value = data[1]|(data[0]<<8);
    
    return(0);
}

/* Implementation of I2C read for 32-bit values */
int32_t mlx90632_i2c_read32(int16_t register_address, uint32_t *value)
{
	uint8_t data[2], data2[2];
    uint32_t Low16, High16;
//	int32_t ret;
//	ret = HAL_I2C_Mem_Read(&hi2c1, CHIP_ADDRESS, register_address, 2, data, sizeof(data), 100);
//	//Endianness
//	return ret;
    
    uint8_t ControlByte, HighAdd, LowAdd, length;
    ControlByte = CHIP_ADDRESS;     //e.g. 011 1010 0 (for 3A)
    length = 2;     // read 2 bytes data
    
    HighAdd = (register_address >> 8) & 0x00FF;
    LowAdd = register_address & 0x00FF;

	IdleI2C();						//Wait for bus Idle
	StartI2C();						//Generate Start condition
	WriteI2C(ControlByte);			//send control byte for write
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(HighAdd);				//Send High Address
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(LowAdd);				//Send Low Address
    IdleI2C();						//Wait for bus Idle

	RestartI2C();					//Generate Restart
	WriteI2C(ControlByte | 0x01);	//send control byte for Read
    IdleI2C();						//Wait for bus Idle

	getsI2C(data, length);			//Read Length number of bytes to Data
	NotAckI2C();					//send Not Ack
	StopI2C();						//Send Stop Condition
    Low16 = data[1]|(data[0]<<8);
    
    register_address = register_address + 1;
    HighAdd = (register_address >> 8) & 0x00FF;
    LowAdd = register_address & 0x00FF;

	IdleI2C();						//Wait for bus Idle
	StartI2C();						//Generate Start condition
	WriteI2C(ControlByte);			//send control byte for write
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(HighAdd);				//Send High Address
    IdleI2C();						//Wait for bus Idle
    
	WriteI2C(LowAdd);				//Send Low Address
    IdleI2C();						//Wait for bus Idle

	RestartI2C();					//Generate Restart
	WriteI2C(ControlByte | 0x01);	//send control byte for Read
    IdleI2C();						//Wait for bus Idle

	getsI2C(data2, length);			//Read Length number of bytes to Data
	NotAckI2C();					//send Not Ack
	StopI2C();
    High16 = data2[1]|(data2[0]<<8);
    
//	*value = data2[0]<<24|data2[1]<<16|data[0]<<8|data[1];
    *value = ((High16 & 0x0000FFFF) << 16) | (Low16 & 0x0000FFFF);
    
    return(0);
}

/* Implementation of I2C write for 16-bit values */
int32_t mlx90632_i2c_write(int16_t register_address, uint16_t value) {
	uint8_t data[2];
//	data[0] = value >> 8;
//	data[1] = value;
//	return HAL_I2C_Mem_Write(&hi2c1, CHIP_ADDRESS, register_address, 2, data, 2, 100);
    
    uint8_t ErrorCode;
    uint8_t ControlByte, HighAdd, LowAdd;
    ControlByte = CHIP_ADDRESS;     //e.g. 011 1010 0 (for 3A)
    HighAdd = (register_address >> 8) & 0x00FF;
    LowAdd = register_address & 0x00FF;
    data[0] = value & 0x00FF;       // LSByte of the 16 bits value
	data[1] = (value >> 8) & 0x00FF;    // MSByte of the 16 bits value
    
	IdleI2C();						//Ensure Module is Idle
	StartI2C();						//Generate Start COndition
	WriteI2C(ControlByte);			//Write Control byte
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status
	
	WriteI2C(HighAdd);
	IdleI2C();						//Write High Address
	WriteI2C(LowAdd);				//Write Low Address
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status

	WriteI2C(data[1]);					//Write Data
	IdleI2C();
    WriteI2C(data[0]);					//Write Data
	IdleI2C();
	StopI2C();						//Initiate Stop Condition
//	EEAckPolling(ControlByte);		//perform Ack Polling
	return(ErrorCode);
}

/* Implementation of reading all calibration parameters for calucation of Ta and To */
int mlx90632_read_eeprom(int32_t *PR, int32_t *PG, int32_t *PO, int32_t *PT, int32_t *Ea, int32_t *Eb, int32_t *Fa, int32_t *Fb, int32_t *Ga, int16_t *Gb, int16_t *Ha, int16_t *Hb, int16_t *Ka)
{
	int32_t ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_R, (uint32_t *) PR);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_G, (uint32_t *) PG);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_O, (uint32_t *) PO);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_T, (uint32_t *) PT);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Ea, (uint32_t *) Ea);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Eb, (uint32_t *) Eb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Fa, (uint32_t *) Fa);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Fb, (uint32_t *) Fb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Ga, (uint32_t *) Ga);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Gb, (uint16_t *) Gb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Ha, (uint16_t *) Ha);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Hb, (uint16_t *) Hb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Ka, (uint16_t *) Ka);
	if(ret < 0)
		return ret;
	return 0;
}

void usleep(int min_range, int max_range) {
	while(--min_range);
}
//**********************************************************************************************************************
