/* 
 * File:   wifi_command.c
 * Author: C12903
 *
 * Created on July 14, 2015, 3:01 PM
 */

#include "wifi_command.h"
#include "p33Fxxxx.h"
#include "GenericTypeDefs.h"

/*****************************************************************************
 * Function Name: void InitWiFiUart( void )
 * Specification: Initialize UART2 module for WiFi module, 19200/8-N-1
 *****************************************************************************/
void InitWiFiUart( void )
{
    #ifdef WiFi_Config
    TRISBbits.TRISB15 = 1;
    RPINR19bits.U2RXR = 15;			// RB15 tied to U2RX
    #endif
	RPOR7bits.RP14R = 0b00101;		// RP14/RB14/Pin25 tied to U2TX
	U2MODEbits.STSEL = 0;			// 1 Stop bit
	U2MODEbits.PDSEL = 0;			// No Parity, 8 data bits
	U2MODEbits.ABAUD = 0;			// Auto-Baud Disabled
	U2MODEbits.BRGH = 0;			// Low Speed mode
	U2BRG = 129;				// BAUD Rate Setting for 19200, UxBRG = ((Fcy/Baudrate)/16)-1 = 40000000/19200/16-1 = 129, (UxBRG=259 for 9600), Fcy=40MHz, 64=10MIPS, 129=20MIPS
	U2STAbits.UTXISEL0 = 1;			// UTXISEL<1:0> = 01 = Interrupt when all transmit operations are completed.
	U2STAbits.UTXISEL1 = 0;
	IPC7bits.U2TXIP = 0;			// UART Transmitter interrupt priority
	IPC7bits.U2RXIP = 0;			// UART Receiver interrupt prioirty
	IFS1bits.U2TXIF = 0;			// Clear UART Transmitter interrupt flag
	IFS1bits.U2RXIF = 0;			// Clear UART Receiver interrupt flag
	IEC1bits.U2TXIE = 0;			// Disable UART Transmitter interrupt
	IEC1bits.U2RXIE = 0;			// Disable UART Receiver interrupt
	U2MODEbits.UARTEN = 1;			// Enable UART
	U2STAbits.UTXEN = 1;			// Enable UART TX, wait at least 104 usec (1/9600) before sending first char
}

/*****************************************************************************
 * Function Name:
 * Specification: WiFi related code.
 *****************************************************************************/
//#if defined(WiFi_Config)
	void WiFi_Module_Config(void)
	{
//		for (delay_counter1=0; delay_counter1<600; delay_counter1++)	//delay needed for WiFi module to power-up before sending command
//		{
//			for (delay2=0; delay2<30000; delay2++);
//		}
		Delay(3000);
		while(WiFi_Enter_Command());
		//send2U2(COMMTIME, COMMTIME_Length);
		send2U2(SETAUTOCON, SETAUTOCON_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(PROTO, PROTO_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETBI, SETBI_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETID, SETID_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETHOST, SETHOST_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(PASSWORD, PASSWORD_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETAUTOCON, SETAUTOCON_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETSECURITY, SETSECURITY_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(COMMREMOTE, COMMREMOTE_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(UARTMODE, UARTMODE_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(IPREMOTE, IPREMOTE_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(SETLINKMON, SETLINKMON_Length);
		Wait_4_UART_Finish();
		WiFi_Save_and_Reboot();
		send2U2(EXIT,EXIT_Length);
		return;
	}

void WiFi_Save_and_Reboot(void)
{
	unsigned char junk = 0;
	unsigned char junk2 = 0;
	unsigned char Array[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	send2U2(SAVE,SAVE_Length);
	junk = 0;
	U2STAbits.OERR = 0;
	IFS1bits.U2RXIF = 0;
	while(junk<20)
	{
		while(IFS1bits.U2RXIF == 0);
		Array[junk] = U2RXREG;
		IFS1bits.U2RXIF = 0;
		junk++;
	}
	while(junk != '<')
	{
		while(IFS1bits.U2RXIF == 0);
		junk = U2RXREG;
		IFS1bits.U2RXIF = 0;
	}
	Wait_4_UART_Finish();
	send2U2(REBOOT,REBOOT_Length);
	junk = 0;
	junk2 = 0;
	while((junk != 'Y') && (junk2 != '*'))
	{
		while(IFS1bits.U2RXIF == 0);
		junk = U2RXREG;
		IFS1bits.U2RXIF = 0;
		if(junk == 'Y')
		{
			while(IFS1bits.U2RXIF == 0);
			junk2 = U2RXREG;
			IFS1bits.U2RXIF = 0;
			if(junk2 != '*')
			{
				junk = 0;
				junk2 = 0;
			}
		}
	}
	Wait_4_UART_Finish();
	//go back into command mode
    while(WiFi_Enter_Command());
	Wait_4_UART_Finish();
	for (delay2=0; delay2<30000; delay2++);
}
//#endif

//#if defined(WiFi_Enable) || defined(WiFi_Config)
unsigned char WiFi_Join_AP(void)
{
    unsigned char junk = 0;
    unsigned char i = 0;
    unsigned char RX_Buffer[5] = {0,0,0,0,0};
    //unsigned char Array[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    unsigned char Network_Status = 0;
    while(WiFi_Enter_Command());
    send2U2(JOINNETWORK, JOINNETWORK_Length);
    Wait_4_UART_Finish();
	for (delay2=0; delay2<30000; delay2++);
	for (delay2=0; delay2<30000; delay2++);
	for (delay2=0; delay2<30000; delay2++);
	for (delay2=0; delay2<30000; delay2++);
    send2U2(GETIP, GETIP_Length);
	IFS1 = 0x0000;
	U2STAbits.OERR = 0;
	T1CONbits.TON = 0;			//Turn off Timer 1
    TMR1 = 0;
    IFS0bits.T1IF = 0;
    junk = 0;
    while((junk != 'I')&&(IFS0bits.T1IF == 0))
    {
    	if(IFS1bits.U2RXIF == 1)
		{
			T1CONbits.TON = 1;
            junk = U2RXREG;
            IFS1bits.U2RXIF = 0;
            TMR1 = 0;
			IFS0bits.T1IF = 0;
        }
    }
    RX_Buffer[0] = junk;
    i = 1;
    TMR1 = 0;
    IFS0bits.T1IF = 0;
    while((i < 5)&&(IFS0bits.T1IF == 0))
    {
        if(IFS1bits.U2RXIF == 1)
        {
            RX_Buffer[i] = U2RXREG;
            IFS1bits.U2RXIF = 0;
            TMR1 = 0;
            i++;
        }
    }
    Wait_4_UART_Finish();
    if(RX_Buffer[3] == 'D')
    {
        Network_Status = 1;         //Network is down
    }else if(RX_Buffer[3] == 'U'){
        Network_Status = 0;         //Network is up
    }
	Nop();
    return(Network_Status);
}

unsigned char WiFi_Open_Socket(void)
{
    unsigned char i = 0;
    unsigned char junk = 0;
    unsigned char Array[5] = {0,0,0,0,0};
    while(WiFi_Enter_Command());
	Delay(3000);
    send2U2(OPEN, OPEN_Length);
    junk = 0;
    TMR1 = 0;
    IFS0bits.T1IF = 0;
	while(junk<5)
	{
		while(IFS1bits.U2RXIF == 0);
		Array[junk] = U2RXREG;
		IFS1bits.U2RXIF = 0;
		junk++;
	}
    while((junk != '*')&&(IFS0bits.T1IF == 0))
    {
    	if(IFS1bits.U2RXIF == 1)
		{
            junk = U2RXREG;
            IFS1bits.U2RXIF = 0;
            TMR1 = 0;
        }
    }
    Array[0] = junk;
    i = 1;
    TMR1 = 0;
    IFS0bits.T1IF = 0;
    while((i < 5)&&(IFS0bits.T1IF == 0))
    {
        if(IFS1bits.U2RXIF == 1)
        {
            Array[i] = U2RXREG;
            IFS1bits.U2RXIF = 0;
            TMR1 = 0;
            i++;
        }
    }
    Wait_4_UART_Finish();
    if(Array[1]=='O')
    {
        return(0);
    }else{
        return(1);
    }
}

unsigned char WiFi_Enter_Command(void)
{
    unsigned char i = 0;
    unsigned char RX_Buffer[5] = {0,0,0,0,0};
    unsigned char junk = 0;
    unsigned char temp = TRUE;
	for (delay2=0; delay2<30000; delay2++);
	sendChar2U2(0x24);		//"$" character
	sendChar2U2(0x24);
	sendChar2U2(0x24);
	while(U2STAbits.TRMT == 0);  //when this bit goes to 1 the transmission is complete.
	IFS1 = 0x0000;
	U2STAbits.OERR = 0;
    i = 0;
    //for (delay2=0; delay2<3000; delay2++);
	//Delay(1500);
	T1CONbits.TON = 1;			//Turn on Timer 1
    TMR1 = 0;
    IFS0bits.T1IF = 0;
    while((i < 3)&&(IFS0bits.T1IF == 0))
    {
		if(IFS1bits.U2RXIF == 1)
		{
	    	RX_Buffer[i] = U2RXREG;
	        IFS1bits.U2RXIF = 0;
	        TMR1 = 0;
	        i++;
		}
    }
    if(RX_Buffer[0] == '$')		//This means the the WiFi module was already in Command mode
    {
		sendChar2U2(0x0D);
		while(U2STAbits.TRMT == 0);  //when this bit goes to 1 the transmission is complete.
		IFS1 = 0x0000;
		junk = U2RXREG;
        temp = FALSE;
    }else if(RX_Buffer[0] == 'C'){ //WiFi Module is now in Command mode
        temp = FALSE;
    }
    Wait_4_UART_Finish();
	Nop();
    return(temp);
}

void Wait_4_UART_Finish(void)
{
	unsigned char nothing = 0;
	TMR1 = 0;
	IFS0bits.T1IF = 0;
	while(IFS0bits.T1IF == 0)
	{
		if(IFS1bits.U2RXIF == 1)
		{
			nothing = U2RXREG;
	        IFS1bits.U2RXIF = 0;
	        TMR1 = 0;
		}
	}
	return;
}
//#endif
