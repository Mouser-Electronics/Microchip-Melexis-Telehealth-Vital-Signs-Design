/* 
 * File:   wifi_command.h
 * Author: C12903
 *
 * Created on July 14, 2015, 3:01 PM
 */

#ifndef WIFI_COMMAND_H
#define	WIFI_COMMAND_H

#ifdef	__cplusplus
extern "C" {
#endif

const char PROTO[15] = {'s','e','t',' ','i','p',' ','p','r','o','t','o',' ','2',0x0D};		// set ip proto to tcp (0:UDP, 1:TCP, 2: TCP Secure, 3: TCP Client, 4: HTTP client)
const char SETBI[10] = {'s','e','t',' ','b',' ','i',' ','0',0x0D};							// set broadcast interval
const char SAVE[5] = {'s','a','v','e',0x0D};												// save
const char REBOOT[7] = {'r','e','b','o','o','t',0x0D};										// reboot
const char SETID[16] = {'s','e','t',' ','o',' ','d',' ','P','u','l','s','e','O','x',0x0D};	// set id
const char EXIT[5] = {'e','x','i','t',0x0D};												// exit
const char SETHOST[22] = {'s','e','t',' ','i',' ','h',' ','1','9','2','.','1','6','8','.','1','.','1','0','7',0x0D}; //internet host
const char PASSWORD[18] = {'s','e','t',' ','w',' ','p',' ','M','P','G','D','e','m','o','A','P',0x0D};  //Network Password
const char SETAUTOCON[19] = {'s','e','t',' ','s','y','s',' ','a','u','t','o','c','o','n','n',' ','1',0x0D}; //Set autoconn, will manually connect to AP
const char SETSECURITY[16] = {'s','e','t',' ','w','l','a','n',' ','a','u','t','h',' ','4',0x0D}; //Set network security type (0:open, 1:WEP-128, 2: WPA1, 4: WPA2-PSK)
const char COMMREMOTE[18] = {'s','e','t',' ','c','o','m','m',' ','r','e','m','o','t','e',' ','0',0x0D};
const char UARTMODE[16] = {'s','e','t',' ','u','a','r','t',' ','m','o','d','e',' ','2',0x0D};
const char IPREMOTE[19] = {'s','e','t',' ','i','p',' ','r','e','m','o','t','e',' ','9','7','7','0',0x0D};	//set port
const char OPEN[5] = {'o','p','e','n',0x0D};
const char JOINNETWORK[17] = {'j','o','i','n',' ','M','P','G','_','D','e','m','o','_','A','P',0x0D};
const char GETIP[7] = {'g','e','t',' ','i','p',0x0D};
const char SETLINKMON [19] = {'s','e','t',' ','w','l','a','n',' ','l','i','n','k','m','o','n',' ','5',0x0D};	//linkmon threshold
const char COMMTIME [17] = {'s','e','t',' ','c','o','m','m',' ','t','i','m','e',' ','2','0',0x0D}; //set the flush time to 20ms
const char close_TCP[6] = {0x63, 0x6c, 0x6f, 0x73, 0x65, 0x0d};								// "close" cr
const char SPO2_symbol[9] = {0x53, 0x50, 0x4f, 0x32, 0x28, 0x25, 0x29, 0x3a, 0x20}; 		// "SPO2(%): "
const char PUL_symbol[9] = {0x50, 0x52, 0x28, 0x62, 0x70, 0x6d, 0x29, 0x3a, 0x20};			// "PR(bpm): "
unsigned char SPO2_String[4], PR_String[4];
unsigned char string_length, sl;
unsigned char wifi_counter;
unsigned int delay2;

#define wificnts    5
#define PROTO_Length 15
#define SETBI_Length 10
#define SAVE_Length 5
#define REBOOT_Length 7
#define SETID_Length 16
#define EXIT_Length 5
#define SETHOST_Length 22
#define PASSWORD_Length 18
#define SETAUTOCON_Length 19
#define SETSECURITY_Length 16
#define COMMREMOTE_Length 18
#define UARTMODE_Length 16
#define IPREMOTE_Length 19
#define OPEN_Length 5
#define JOINNETWORK_Length 17
#define GETIP_Length 7
#define SETLINKMON_Length 19
#define COMMTIME_Length 17

void InitWiFiUart( void );
void WiFi_Module_Config(void);
unsigned char WiFi_Enter_Command(void);
unsigned char WiFi_Join_AP(void);
unsigned char WiFi_Open_Socket(void);
void WiFi_Save_and_Reboot(void);
void Wait_4_UART_Finish(void);
void WiFi_TASK(void);


#ifdef	__cplusplus
}
#endif

#endif	/* WIFI_COMMAND_H */

